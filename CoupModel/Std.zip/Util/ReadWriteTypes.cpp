#include "../std.h"
#include "../Util/ReadWriteTypes.h"
#include "FUtil.h"


#include "../std.h"
#include "../Util/ReadWriteTypes.h"
#include "FUtil.h"


ReadWriteTypes::ReadWriteTypes(void)
{
	m_FileVersionNumberRead = 51;
	m_ShortTimeRead = true;
	m_binary = false;
}


ReadWriteTypes::~ReadWriteTypes(void)
{
}

bool ReadWriteTypes::OpenDocFileIn(std::string filename, bool binary_type )
{
	if (binary_type) {
		m_DocFileIn.open(filename, std::ios_base::in|std::ios_base::binary);
		m_binary = true;
	}
	else {
		m_DocFileIn.open(filename, std::ios_base::in);
		m_binary = false;

	}
	if (!m_DocFileIn.good())
	{
		m_DocFileIn.clear();
		m_DocFileIn.open(filename);
	}
	/*
	m_DocFileIn.seekg(0, ios::end);
	auto end=m_DocFileIn.tellg();

	m_DocFileIn.seekg(0, ios::beg);
	char buffer[40000] = { 0 };
	char buf[1000] = {0 };
	vector<size_t> bufm;

	char byte;
	size_t count=0;
	size_t all = 0;
	m_DocFileIn.seekg(0, ios::beg);
	auto pos_prior = m_DocFileIn.tellg();


	signed char il;

	m_DocFileIn.read((char*)(&il), 1);





	m_DocFileIn.read(buf, 100);
	auto pos_post = m_DocFileIn.tellg();
	pos_post -= 1;
	m_DocFileIn.seekg(pos_post, ios::beg);

	
	while (m_DocFileIn.good()) {
		all++;
		m_DocFileIn.read((char*)(&il), 1);
		//m_DocFileIn.read(&byte, 1);
		auto pos_post = m_DocFileIn.tellg();
		auto pos_prior = pos_post;
		bufm.push_back(size_t(pos_post));
		buffer[all - 1] = il;
	}



	vector<size_t> kollpos;
	for (size_t i = 0; i < all; i++) {
		if (buffer[i] == 83 && buffer[i + 1] == 69) {
			kollpos.push_back(i);
		}
	}


	m_DocFileIn.seekg(0, ios::beg);*/




	m_FileName = filename;


	return m_DocFileIn.good();
}

bool ReadWriteTypes::OpenDocFileout(std::string filename)
{
	if (FUtil::IsFileExisting(filename))
		m_DocFileOut.open(filename, std::ios_base::in|std::ios_base::out);
	else
		m_DocFileOut.open(filename, std::ios_base::out);

	size_t n = 0;
	SetPutPosition(&n);
	m_FileName = filename;
	return m_DocFileOut.good();
}

void ReadWriteTypes::CloseFileIn()
{
	m_DocFileIn.close();
}

void ReadWriteTypes::CloseFileOut()
{
	m_DocFileOut.close();
}

bool ReadWriteTypes::wString(std::string* str)
{
	size_t il = str->size();
	if (il > 0)
		m_DocFileOut << *str << std::endl;

	return true;
}

bool ReadWriteTypes::rString(std::string* str)
{
	if (m_binary) {
		unsigned char il;
		size_t ic;
		char cc;
		auto s = m_DocFileIn.tellg();
		if (s < 0) return false;
		m_DocFileIn.read((char*)(&il), 1);
		cc = il;
		if (il == 255) {
			char s1, s2;
			m_DocFileIn.read((char*)(&s1), 1);
			m_DocFileIn.read((char*)(&s2), 1);
			ic = 255 + s2;
			m_DocFileIn.seekg(s, std::ios::beg);
			s = m_DocFileIn.tellg();
			m_DocFileIn.read((char*)(&il), 1);
			m_DocFileIn.read((char*)&ic, 2);


		}
		else if (cc < 0xFF) {
			ic = il;

		}
		else if (cc == 0xFF) {
			char s1, s2;
			s = m_DocFileIn.tellg();
			m_DocFileIn.read((char*)(&s1), 1);
			m_DocFileIn.read((char*)(&s2), 1);
			ic = 255 + s2;
			//	m_DocFileIn.read((char*)&ic, 2);

		}
		else {
			m_DocFileIn.read((char*)&ic, 2);


		}

		//m_DocFileIn.read((char*)(&ic),sizeof(ic));
		if (il == 0xfffe) {
			int ivv;
			m_DocFileIn.read((char*)&ivv, 2);

			str->clear();
			long long s = m_DocFileIn.tellg();
			if (s < 0) {
				return false;

			}
		}
		else if (il == 0xffff) {
			int ivv;
			m_DocFileIn.read((char*)&ivv, 4);


		}
		else {
			m_DocFileIn.read(m_cbuf, ic);
			str->clear();
			if (ic > 0)
				str->assign(&m_cbuf[0], ic);
		}
	}
	else {
		size_t il;
		std::string s;
		m_DocFileIn >> s;
		il = s.size();

		if (il > 0)
		{
			char* buffer = new char[il];
			m_DocFileIn.getline(buffer, il + 1);
			*str = buffer;
			delete[] buffer;
		}
	}

	return true;
}

bool ReadWriteTypes::rInt(int* iv)
{
	m_DocFileIn >> *iv;
	return true;
}

bool ReadWriteTypes::rsize_t(size_t* iv)
{
	if (m_binary) {
		unsigned int i;
		auto prior = m_DocFileIn.tellg();
		m_DocFileIn.read((char*)(&i), 4);
		auto post = m_DocFileIn.tellg();
		if (post - prior != 4) {
			prior += 4;
			m_DocFileIn.seekg(prior);
		    post = m_DocFileIn.tellg();


		}
		*iv = i;
	}
	else 
		m_DocFileIn >> *iv;
	return m_DocFileIn.good();
}

bool ReadWriteTypes::ruint(unsigned int* iv)
{
	if (m_binary) {
		m_DocFileIn.read(reinterpret_cast<char*>(&*iv), sizeof(unsigned int));
	}
	else
		m_DocFileIn >> *iv;
	return m_DocFileIn.good();
}

bool ReadWriteTypes::SetGetPosition(size_t* iv)
{
	m_DocFileIn.seekg(*iv, std::ios::beg);
	return true;
}

bool ReadWriteTypes::SetPutPosition(size_t* iv)
{
	m_DocFileOut.seekp(*iv);
	if (m_DocFileOut.tellg() == *iv)
		return true;
	return false;
}

bool ReadWriteTypes::rBOOL(bool* iv)
{
	int iBOOL;
	m_DocFileIn >> iBOOL;
	*iv = (iBOOL != 0);
	return true;
}

bool ReadWriteTypes::rbool(bool* iv)
{
	m_DocFileIn >> *iv;
	return true;
}

bool ReadWriteTypes::rLong(long* iv)
{
	m_DocFileIn >> *iv;
	return true;
}

bool ReadWriteTypes::ruLong(unsigned long* iv)
{
	m_DocFileIn >> *iv;
	return true;
}

bool ReadWriteTypes::rFloat(float* f)
{
	if (m_binary) {
		float v;
		auto prior = m_DocFileIn.tellg();
		m_DocFileIn.read((char*)&v, 4);
		auto post = m_DocFileIn.tellg();
		if (m_DocFileIn.fail()) {
			std::cerr << "Read error or EOF reached!" << std::endl;
			m_DocFileIn.clear();  // Clear error state
			m_DocFileIn.seekg(prior);  // Reset position
		}
		else if (post - prior != 4) {
			std::cerr << "Unexpected read size! Read: " << (post - prior) << " bytes" << std::endl;
		}

		*f = v;
		//m_DocFileIn.read(reinterpret_cast<char*>(&*f), sizeof(float));

	}
	else {
		m_DocFileIn >> *f;
	}
	return true;
}

bool ReadWriteTypes::rFloatArray(float* f, size_t n)
{
	for (size_t i = 0; i < n; i++)
		m_DocFileIn >> f[i];
	return m_DocFileIn.good();
}

bool ReadWriteTypes::ruLongArray(unsigned long* v, unsigned long n)
{
	for (unsigned long i = 0; i < n; i++)
		m_DocFileIn >> v[i];
	return m_DocFileIn.good();
}

std::vector<size_t> ReadWriteTypes::rsize_tArray(size_t n,  size_t line_break)
{
	std::string str, str_line;
	if(line_break<n)
		getline(m_DocFileIn, str, ',');

	std::vector<size_t> v; v.resize(n);
	for (size_t i = 0; i < n; i++)
	{
		if ((i + 1) % line_break == 0) {
			if (i < n - 1) {
				getline(m_DocFileIn, str);	getline(m_DocFileIn, str_line, ',');
			}
		}
		else
			getline(m_DocFileIn, str, ',');
		auto value = atoi(str.c_str());
		v[i]=value;
	}
	return v;
}
bool ReadWriteTypes::wFloatArray(const std::vector<float> &f) 
{
	for (size_t i = 0; i < f.size(); i++)
		m_DocFileOut << f[i] << " ";
	m_DocFileOut << std::endl;
	return m_DocFileOut.good();
}


bool ReadWriteTypes::wFloatArray(float* f, size_t n)
{
	for (size_t i = 0; i < n; i++)
		m_DocFileOut << f[i] << " ";
	m_DocFileOut << std::endl;
	return m_DocFileOut.good();
}

bool ReadWriteTypes::wFloatArray2(const std::vector<float> &v, size_t n, size_t line_break)
{
	std::ofstream debug("debug_log.txt", std::ios::app);




	size_t line_count = 1;
	m_DocFileOut << line_count << ',';
	for (size_t i = 0; i < n; i++) {
		debug << "Failed at i=" << i << ", tellp=" << m_DocFileOut.tellp() << std::endl;
		if (!m_DocFileOut.good()) return false;
		if (abs(v[i]) < 1.E37) {
			if (abs(v[i]) < 1.E-20)
				m_DocFileOut << 0.;
			else
				m_DocFileOut << v[i];
		}
		if ((i + 1) % line_break == 0) {
			if(m_DocFileOut.good() && m_DocFileOut.tellp() > 0) // Check if the stream is good and not at the end
			{
				m_DocFileOut << std::endl << line_count << ',';
			}
			else
			{
				std::cerr << "Error writing to file." << std::endl;
				return false; // Return false if there was an error writing to the file
			}
			line_count++;
			if (i < n - 1) {
				m_DocFileOut << std::endl << line_count << ',';
			}
		}
		else m_DocFileOut << ',';
	}
	m_DocFileOut << std::endl;
	return m_DocFileOut.good();
}

bool ReadWriteTypes::wFloatArray2(const std::vector<float>& v, size_t line_break) 
{
	size_t line_count = 1;
	m_DocFileOut << line_count << ',';
	for (size_t i = 0; i < v.size(); i++) {
		if (abs(v[i]) < 1.E37) {
			if (abs(v[i]) < 1.E-20)
				m_DocFileOut << 0.;
			else
				m_DocFileOut << v[i];
		}
		if ((i + 1) % line_break == 0) {
			line_count++;
			if (i < v.size() - 1) {
				m_DocFileOut << std::endl << line_count << ',';
			}
		}
		else m_DocFileOut << ",";
	}
	m_DocFileOut << std::endl;
	return m_DocFileOut.good();
}


std::vector<float> ReadWriteTypes::rFloatArray2(size_t n, size_t line_break) 
{
	std::vector<float> v;	v.resize(n);
	std::string str, str_line;
	getline(m_DocFileIn, str, ',');
	for (size_t i = 0; i < n; i++)
	{
		if ((i + 1) % line_break == 0) {
			if (i < n - 1) {
				getline(m_DocFileIn, str);	getline(m_DocFileIn, str_line, ',');
			}
		}
		else
			getline(m_DocFileIn,str,',');
		float value;
		if(str.size()>0)		
			value = atof(str.c_str());
		else
			value=MISSING;
		v[i]=value;
	}
	return v;
}

bool ReadWriteTypes::wuLongArray(const std::vector<unsigned long> &v, size_t n)
{
	for (size_t i = 0; i < n; i++)
		m_DocFileOut << v[i] << " ";
	m_DocFileOut << std::endl;
	return m_DocFileOut.good();
}

bool ReadWriteTypes::wsize_tArray(const std::vector<size_t> &v, size_t n, size_t line_break)
{
	size_t line_count = 1;
	if (n == std::string::npos) n = v.size();
	if(line_break<n)
		m_DocFileOut << line_count<<',';
	for (size_t i = 0; i < n; i++) {
		m_DocFileOut << v[i];
		if (i + 1 % line_break == 0) {
			line_count++;
			if(i<n-1) {
				m_DocFileOut << std::endl << line_count << ',';
			}
		}
		else m_DocFileOut << ",";
	}
	m_DocFileOut << std::endl;
	return m_DocFileOut.good();
}

bool ReadWriteTypes::rDouble(double* f)
{
	m_DocFileIn >> *f;
	return true;
}

bool ReadWriteTypes::wInt(int* iv)
{
	m_DocFileOut << *iv << std::endl;
	return true;
}

bool ReadWriteTypes::wInt(unsigned int* iv)
{
	m_DocFileOut << *iv << std::endl;
	return m_DocFileOut.good();
}

bool ReadWriteTypes::wSize_t(size_t* iv)
{
	m_DocFileOut << *iv << std::endl;
	return m_DocFileOut.good();
}

bool ReadWriteTypes::wPosition()
{
	auto pos = m_DocFileOut.tellp();
	size_t ipos = size_t(pos);
	m_DocFileOut << ipos << std::endl;
	return m_DocFileOut.good();
}

bool ReadWriteTypes::wbool(bool* iv)
{
	m_DocFileOut << *iv << std::endl;
	return true;
}

bool ReadWriteTypes::wLong(long* iv)
{
	m_DocFileOut << *iv << std::endl;
	return true;
}

bool ReadWriteTypes::wFloat(float* f)
{
	m_DocFileOut << *f << std::endl;
	return true;
}

bool ReadWriteTypes::wDouble(double* f)
{
	m_DocFileOut << *f << std::endl;
	return true;
}

bool ReadWriteTypes::wTime(time_t* time)
{
	m_DocFileOut << *time << std::endl;
	return true;
}

bool ReadWriteTypes::rTime(time_t* time)
{
	m_DocFileIn >> *time;
	return true;
}

size_t ReadWriteTypes::GetCurrentInPosition()
{
	auto actpos = m_DocFileIn.tellg();
	return size_t(actpos);
}

size_t ReadWriteTypes::GetInputFileSize()
{
	m_DocFileIn.seekg(0, std::ios::end);
	auto actpos = m_DocFileIn.tellg();
	m_DocFileIn.seekg(0, std::ios::beg);
	return size_t(actpos);
}

std::streamsize ReadWriteTypes::GetStdInputFileSize()
{
	m_DocFileIn.seekg(0, std::ios::end);
	std::streamsize actpos = m_DocFileIn.tellg();
	m_DocFileIn.seekg(0, std::ios::beg);
	return actpos;
}

