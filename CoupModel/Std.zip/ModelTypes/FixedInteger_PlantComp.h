#pragma once
//int const NUM_BIOELEM = 4;
enum BIO_ELEM { _C_, _N_, _P_, _TE_, NUM_BIOELEM };
/*int const _C_ = 0;
int const _N_ = 1;
int const  _P_ = 2;
int const _TE_ = 3;*/
int const _NEWMOBILE = 0;
int const _LEAF = 1;
int const _STEM = 2;
int const _GRAIN = 3;
int const _MOBILE = 4;
int const _OLD_LEAF = 5;
int const _OLD_STEM = 6;
int const _ROOT = 7;
int const _COARSE_ROOT = 8;
int const _OLD_ROOT = 9;
int const _OLD_COARSE_ROOT = 10;
int const _FUNGI = 11;
int const _ABOVEG = 12;
int const _BELOWG = 13;
int const _TOTAL = 14;
int const NUM_PLANT_COMP = 11; //Changed to 12 for inclusion of _CFungi
int const _ROOT_ALL = 0;
int const _PLANT_WHOLE = 1;
int const _LEAF_ALL = 2;
int const _ABOVE_GROUND = 3;
int const _BELOW_GROUND = 4;
int const NUM_SUM_STATES = 6; // Changed from 5 to 6 for inclusion of Fungi
int const _LEAF_ = 0;
int const _GRAIN_ = 1;
int const _STEM_ = 2;
int const _ROOT_ = 3;
int const _COARSE_ROOT_ = 4;
int const _FUNGI_ = 5;

enum PlantComp2{NEWMOBILE, LEAF, STEM, GRAIN, MOBILE, OLD_LEAF, OLD_STEM, ROOT, COARSE_ROOT, OLD_ROOT, OLD_COARSE_ROOT, FUNGI, ABOVEGROUND, BELOWGROUND,TOTAL, DEAD_ABOVEGROUND, DEAD_BELOWGROUND};


int const NUM_CARBON_RATIO_AUX = 6;

int const NUM_PLANT_FUNGI_COMP = 12;
int const NUM_REALLOCATION = 23;
int const LEAF_GRAIN = 0;
int const STEM_GRAIN = 1;
int const ROOT_GRAIN = 2;
int const COARSE_ROOT_GRAIN = 3;
int const LEAF_STEM = 4;
int const ROOT_LEAF = 5;
int const LEAF_OLD_LEAF = 6;
int const STEM_OLD_STEM = 7;
int const ROOT_OLD_ROOT = 8;
int const COARSE_ROOT_OLD_COARSE_ROOT = 9;
int const LEAF_MOBILE_RETURN = 10;
int const OLD_LEAF_MOBILE_RETURN = 11;
int const NEWMOBILE_FUNGI = 12;
int const OLD_LEAF_MOBILE = 13;
int const OLD_STEM_MOBILE = 14;
int const OLD_ROOT_MOBILE = 15;
int const OLD_COARSE_ROOT_MOBILE = 16;
int const LEAF_MOBILE = 17;
int const STEM_MOBILE = 18;
int const ROOT_MOBILE = 19;
int const COARSE_ROOT_MOBILE = 20;
int const MOBILE_LEAF = 21;
int const MOBILE_NEWMOBILE = 22;
int const NUM_UPTAKE = 4;
int const PLANT_TOT_N = 0;
int const PLANT_ORG_N = 1;
int const FUNGI_TOT_N = 2;
int const FUNGI_ORG_N = 3;

int const NUM_ORG_FORMS = 6;
/*int const _L1 = 0;
int const _L2 = 1;
int const _F = 2;
int const _H = 3;
int const _MIC = 4;
int const _DIS = 5;
int const _ORG_ALL = 6;*/
enum SoilOrgFrom {_L1, _L2, _F, _H, _MIC, _DIS, _ORG_All};

int const NUM_ORG_TRANSFORMATION = 21;
int const L1_HUM = 0;
int const L2_HUM = 1;
int const F_HUM = 2;
int const HUM_HUM = 3;
int const L1_PLANTUPTAKE = 4;
int const L2_PLANTUPTAKE = 5;
int const F_PLANTUPTAKE = 6;
int const H_PLANTUPTAKE = 7;
int const L1_DIS = 8;
int const L2_DIS = 9;
int const F_DIS = 10;
int const H_DIS = 11;
int const MIC_DIS = 12;
int const L1_MIC = 13;
int const L2_MIC = 14;
int const F_MIC = 15;
int const H_MIC = 16;
int const L1_FUNGIUPTAKE = 17;
int const L2_FUNGITUPTAKE = 18;
int const F_FUNGIUPTAKE = 19;
int const H_FUNGIUPTAKE = 20;

