#pragma once
#include "SimB.h" 

class Sw : public SimB {
 public:
	Sw(size_t *target, enum datatype data, enum elements elem, enum fysprocess fproc, enum bioprocess bproc, enum userlevel ulev);

	~Sw();
	void Def(size_t module_no, std::string varname, int initv, std::string options, std::string conditions, int recalc);  
public:
	virtual size_t GetIntValue() const {return *_ptarget;};
	size_t GetOriginalIntValue() const {return org_value;};
	size_t SetIntValue(size_t ivalue) {old_value=*_ptarget;_IsOldValue=true;  *_ptarget=ivalue; SendNotice();if(*_ptarget!=org_value) SimB::SetNotOriginalValue();return m_recalc;};
	void SetNotOldValue() {_IsOldValue=false;};
	std::string GetOption(size_t index) {
		if(index<_options.size()) 
			return _options[index]; 
		else 
			return ""; 
	};
	size_t GetNumOptions();
	bool IsOldValue() noexcept {return _IsOldValue;};
	size_t SetStrValue(std::string str);
	size_t SetDBStrValue(std::string str);
	std::string GetName() {return SimB::GetName();};
	void SetDBIntValue(size_t value) noexcept {_DBIntValue=value; };
	size_t GetDBIntValue()  noexcept {return _DBIntValue;};
	size_t GetOldIntValue()  noexcept {return old_value;};
protected:
	size_t *_ptarget;
	size_t org_value;
	size_t old_value;
	bool _IsOldValue;
	size_t m_recalc;
private:
	std::vector <std::string> _options;
};