#pragma once
#include "Par.h"

class Ps :	public Par
{
	public:
		Ps(void);
		Ps(double *target, definitions def);
		Ps(double *target, enum datatype data, enum elements elem, enum fysprocess fproc, enum bioprocess bproc, enum userlevel ulev);
		~Ps(void);
		void Def(size_t ModuleNo, std::string name, double init, std::string_view unit, std::string conditions, 
			double errormin, double errormax, double warningmin, double warningmax,
			int recalc=0,  int view=0);
		size_t SetValue(double v) {_oldValue=*_ptarget;_IsOldValue=true;
		*_ptarget=v; 
		if(*_ptarget!=GetOriginalValue()) SetNotOriginalValue();
		return _recalc_option;
			};
		double GetValue() const {return *_ptarget;};
		double GetOldValue() const {return _oldValue;};
		void SetNotOldValue() {_IsOldValue=false;};
		void SetDBValue(double v) {_DBvalue=v;};
		double GetDBValue() const {return _DBvalue;};
		void SetMinValue(double v)  noexcept {_min=v;};
		double GetMinValue()  noexcept {return _min;};
		void SetMaxValue(double v) {_max=v;};
		double GetMaxValue()  noexcept {return _max;};
		void SetWarnMinValue(double v) {_wmin=v;};
		double GetWarnMinValue() noexcept {return _wmin;};
		void SetWarnMaxValue(double v) {_wmax=v;};
		double GetWarnMaxValue()  noexcept {return _wmax;};
		void Apply() {;};
		void EditApply() {;};
		virtual double GetOriginalValue()  noexcept {return _orgFValue;};
		void SetOriginalValue(double value)  noexcept {_orgFValue=value;};
		//double GetOriginalValue() {return _orgFValue;};
		
		int MR_Get_Dim()  noexcept {return _mr.Dimension;};
		double MR_Get_Min()  noexcept {return _mr.Min;};
		double MR_Get_Max()  noexcept {return _mr.Max;};
		double MR_Get_Start()  noexcept {return _mr.Start;};
		double MR_Get_RelChange()  noexcept {return _mr.RelChange;};
		enum MR_METHOD MR_Get_Method()  noexcept {return _mr.Method;};
		SIMB Get_MR_PAR_Dependence() noexcept {return _mr.MR_Dependent;};
		SimB *Get_MR_ParDependence()  noexcept {return _mr.MR_Dependent.pBase;};
		size_t Get_MR_ParDependenceIndex() noexcept {return _mr.MR_Dependent.TabIndex;};
		void MR_Set_Dim(int value)  noexcept {_mr.Dimension=value;};
		void MR_Set_Min(double value)  noexcept {_mr.Min=value;};
		void MR_Set_Max(double value) noexcept {_mr.Max=value;};
		void MR_Set_Start(double value)  noexcept {_mr.Start=value;};
		void MR_Set_Method(enum MR_METHOD value)  noexcept {_mr.Method=value;};
		void MR_Set_RelChange(double value) noexcept { _mr.RelChange=value;};
		void Set_MR_ParDependence(SimB *pSimB, size_t depIndex=-1) noexcept {_mr.MR_Dependent.pBase=pSimB;_mr.MR_Dependent.TabIndex=depIndex;};
		void Set_MR_ParDependenceIndex(size_t index) noexcept {_mr.MR_Dependent.TabIndex=index;};
		void Set_MR_PAR_Dependence(SIMB value) noexcept {  _mr.MR_Dependent=value;};

		
		size_t MR_GetSizeTable() {return _mr_Tab_Value.size();};
		void MR_Reset_Table() {_mr_Tab_Value.clear();};
		void MR_Append_TableValue(double value) {_mr_Tab_Value.push_back(value);};
		double MR_Get_TabValue(size_t index) {return _mr_Tab_Value[index];};
		void   MR_Set_TabValue(size_t index, double value) {_mr_Tab_Value[index]=value;};


		void def(int ModuleNo, std::string name, double init, std::string_view unit, std::string conditions, 
			double errormin, double errormax, double warningmin, double warningmax,
			int recalc=0,  int view=0);
		bool IsOldValue()  noexcept {return _IsOldValue;};

		std::string GetProcess() {return _Process;};

		void MR_Set_Bins(size_t nbins) {  m_n_bins = nbins;};
		bool IsViewValid() {if(view>0) return true;	return false;};



		long GetChaDate(size_t index) {if(index<ChaDateLong.size()) return ChaDateLong[index]; return -1;};
		double GetChaParValue(size_t index) {if(index<ChaParValue.size()) return ChaParValue[index]; return MISSING;};
		size_t GetNumChaDates() {return ChaDateLong.size();};
		bool SetChaDateAndValue(long minnew, double newvalue) { 
				long test;
				for(size_t i=0;i<ChaDateLong.size();i++){
					test=ChaDateLong[i];
					if(test>minnew) {
						ChaDateLong[i]=minnew;
						ChaParValue[i]=newvalue;
						ChaParIndex[i]= std::string::npos;
						return true;
					}
					else if(test==minnew) {
						ChaDateLong[i]=minnew;
						ChaParValue[i]=newvalue;
						return true;
					}

				}
				ChaDateLong.push_back(minnew);
				ChaParValue.push_back(newvalue);
				ChaParIndex.push_back(std::string::npos);
				return false;			

		};
		
		bool DeleteChaDate(size_t index) {ChaDateLong.erase(ChaDateLong.begin()+index);ChaParValue.erase(ChaParValue.begin()+index);return true;};
		bool ResetChaDates() { ChaDateLong.clear(); ChaParValue.clear();return true;};
		void MR_Set_Monitoring(size_t value) {_mrMonitoring=value;};
		size_t MR_Get_Monitoring() {return _mrMonitoring;};

	



	private:

	double _orgFValue;
	double *_ptarget; 
	double _min,_max, _wmin, _wmax;
	double _DBvalue;
	double _oldValue;
	std::vector<double> _mr_Tab_Value;
	std::vector<long> ChaDateLong;
	std::vector<double> ChaParValue;
	std::vector<size_t> ChaParIndex;
	MR_PAR _mr;
	std::string _ViewTitle;
	std::string _Process;
	size_t _mrMonitoring;
	size_t m_n_bins;
	size_t view;
	std::string GLegend, GLeftTitle, GXTitle;
	double GXmin, GXmax;
	size_t GPointType, GraphType;

	bool _IsOldValue;
};

