#pragma once
#include "./NC_Organic.h"

class NC_GasFlux_Functions : public NC_Organic
{
	public:
		NC_GasFlux_Functions(void);
		~NC_GasFlux_Functions(void);
		bool Def();
		bool FunctionDef();


size_t  Trace_Gas_Emissions, Oxygen_Model, Methane_Model,Methane_Plant_Oxidation, Methane_Soil_Oxidation,
Methane_Plant_Emission, Methane_SoilBoundary_Flux,Methane_Aerenchyma_Emission, Ebullition, MethaneConvectionSoilFlux;
size_t Dissolved_OxygenGas, MethaneProductionModel;
size_t COS_Model, COS_PlantModel, COS_SoilModel;
size_t  N2O_YearlyFluxes/*, CO2_SoilModel Moved to AbioticResponses_Functions*/;  
vector<double> Oxygen, Oxygen_Flux, Oxygen_Consumption, CO2Soil, CO2_FluxSoil,CO2_Production;
vector<double> Init_Oxygen_Conc, Oxygen_Conc, Air_Porosity, Init_CO2_Conc/*, CO2_Conc*/;
double  DO2_Tortuosity , AnBal_ShapeCoef, IntDiffRedFrac, IntDiffRedFracBase, Oxygen_Flux_Infil;
double  DCO2_Tortuosity; 
double  DCO2_PowerCoefSoilDiff, DCO2_AirThreshold, DCO2Min_Soil;
double  NO_Rate, N2O_Rate, N2_Rate;
double  MaxFracN2O, MaxFracNO;
double  N2O_TempMax, N2O_TempOpt, N2O_TempShape, N2O_RelSatCrit, N2O_RelSatForm;
double  NO_RelSatCrit, NO_RelSatForm;
double  NO_pH_Coef;
double  Denit_Act_PowerCoef;
double  N2O_10Percentil, N2O_50Percentil, N2O_90Percentil, N2O_Ymean;
double  NO_10Percentil, NO_50Percentil, NO_90Percentil, NO_Ymean;
vector<double>  pH_Value;
vector<P*> mTab_Ox, mTab_Ph,mTab_Aere;

vector<double> NO, N2O, N2;
vector<double> NO_SoilFlux, N2O_SoilFlux, N2_SoilFlux, NO_NitriFlux, N2O_NitriFlux;
vector<double> NO_Exchange, N2O_Exchange, N2_Exchange;
double  NO_TotExchange, N2O_TotExchange, N2_TotExchange;

// New Methane Model
vector<double> CH4_Prod, CH4_Oxidation, CH4_SoilFlux, CH4;
double  CH4_RateCoefRatio;
double CH4_ProductionQ10;

//double CH4_Conc_rel, Oxygen_Conc_rel, liqfrac, epsilon_ch4, kh_cc_ch4, epsilon_o2, kh_cc_o2;
vector<double> RootFrac;
vector<double> CH4_Ebullition, CH4_PlantWaterUptake, CH4_Conc_Water, Oxygen_Conc_Water, CH4_PlantTransport;
//vector<double> CH4_Conc_rel, Oxygen_Conc_rel, RootFrac, liqfrac, epsilon_ch4, kh_cc_ch4, epsilon_o2, kh_cc_o2;
vector<double> CH4_Demand, O2_Demand, CH4_Aere, O2_Aere, O2_Oxidation, OxygenStress, MethaneStress;

////Added by Marco
vector<double> CH4_OxidationSoilBacteria,  CH4_OxidationPlantRoot, MethaneBubbleFunc;
double  CH4_OxidationReactionRate, CH4_HalfRateOxConstant, Oxygen_HalfRateOxConstant, CH4_PlantOxidationRate, CH4_Water_Diff_Coef;
double  CH4_EbullMax, CH4_BubbleRateConstant;
double BubbleFrac, RatioPressThreshold;

double  CH4_PlantOxidationEff, CH4_WaterPlantCoef, CH4_ResistanceAir;
double CH4_AccBubbles, CH4_AccPlant, CH4_AccEmission, CH4_DiffTotStorage, CH4_MassBalanceCheck;
double CH4_AccProduction, CH4_AccOxidation;
double CH4_ResistanceAirLogScale;

double CH4_TotPlantUptake, CH4_TotPlantEmission, CH4_TotPlantOxidation, CH4_TotSoilOxidation;
////Added by Marco III;


double  CH4_PlantOxShape, CH4_LimitWaterUptake, CH4_Air_Diff_Coef;
vector<double>  CH4_AirSoilFlux,  CH4_CONC_AIR, O2_CONC_AIR;
double   CH4_HStandard, CH4_HTempSens, O2_HStandard, O2_HTempSens, H_TRef, CH4_WaterPowerCoef, CH4_InitConc, CH4_SurfaceEmission;
;
double    CH4_TotSoilFlux, CH4_TotSysFlux, CH4_CONC_Atm, CO2_CONC_Atm;
double AereScale, D_CH4_Aere, D_O2_Aere;//, LAI_Aere;
vector<double> NPPyr, Porosity_Tiller, NPP_Ratio, Rob;
double O2_CONC_Atm;
double CH4_TotSoilProductionFlux, CH4_TotSoilStorage;
double CO2_Flux_Out;


double COS_TranspirationRatio, COS_PhotoSynthesisRatio;	//Parameters
double COS_TranspirationPotMaxRatio, COS_TranspirationPotRatio;
double COS_AirResistCoef, COS_CanopyResistCoef, COS_RadHalfCoef, COS_RadScaleCoef;
double COS_HalfCondCanopy, COS_HalfCondAir;
double COS_SoilRespiratonRatio;							//Parameters
double COS_TotPlantUptake, COS_TotSoilUptake, COS_EcoSystemFlux;
double COS_Option1, COS_Option2, COS_Option3, COS_Option4, COS_Option5, COS_Option6;
;
;
// New CH4 model develop 2007;
//Other Existing variables to use: RootDensity;;
//			         GSI Common Response Function (GSIFunction) (do we have already one?);
//				 WaterFlow[i] ////Water vertical flow in soi;
;
;
;
;
//	LocalVariables;
//Real, Parameter	:: OxygenConcAtm = 0.2095	// Volumetric concentration of oxygen in atmosphere;
double OxygenMassConcAtm, MethaneMassConcAtm, CO2MassConcAtm;
vector<double> OxygenGradients, DO2_SoilCoef, DO2_ExCoefSoil, DCO2_SoilCoef;
vector<double> DenitGrowth_NO3, DenitGrowth_NO2, DenitGrowth_NO, DenitGrowth_N2O, DenitUptakeFactor;
vector<double> DailyValuesNO, DailyValuesN2O;
;
vector<double> DenitUptakeMin, DenitUptakeOrg;

std::function<double(double)> f_COS_Plant,f_COS_PlantTransp, f_COS_PlantTranspPotMax, f_COS_PlantTranspPot, f_COS_Soil;

std::function<double(double)> f_MethaneOxidation, f_MethaneOxidationRegulation, f_MethaneOxidationRegulationCH4, f_PlantRootRespRegulation;
std::function<double(double,double)> f_MethaneOxidationRegulationCH4_O2;
std::function<double(double, double)> f_MethaneVolatility, f_EbullitionPress;
std::function<double(double)> f_GasWaterConcCH4, f_GasWaterConcO2;
std::function<double(double, double, double)> f_Ebullition;
std::function<double(double, double, double)> f_MethaneProduction_OneLitter;
std::function<double(double, double)> f_PlantEmissionbyWaterUptake;
std::function<double(double, double)> f_MethaneBoundaryLayerFlux;
std::function<double(double, double, double)> f_MethaneDynResBoundaryLayerFlux;
std::function<double(double)> f_MethaneOxidationInPlant;
std::function<double(double, double, double, double)> f_MethaneProduction_TwoLitter;

std::function<vector<double>(vector<double>, std::vector<double>, std::vector<double>, std::vector<double>, std::vector<double>, std::vector<double>)> f_MethaneProdVector_TwoLitter;
std::function<vector<double>(vector<double>, std::vector<double>, std::vector<double>, std::vector<double>, std::vector<double>)> f_MethaneProdVector_OneLitter;
std::function<vector<double>(vector<double>, std::vector<double>, std::vector<double>, std::vector<double>, std::vector<double>, size_t OrgIndex)> f_MethaneProdVector_ByLitterIndex;
std::function<double(double, double, double, double, double)> f_MethaneResistanceSoilSurface;
std::function<double(double, double, double, double, double,double,double,double,double,double)> f_PlantEmissionbyAerenchyma,f_OxygenDiffusionbyAerenchyma;
std::function<double(double)> f_AnaerobicFraction;

std::function<double(double, double)> f_OxygenDiffuctionCoef;
std::function<double(double, double)> f_CarbonDiOxideDiffuctionCoef;
std::function<double(double, double)> f_OxygenDensityFrom_Volume_Temp;
std::function<double(double, double)> f_CarbonDioOxideDensityFrom_Volume_Temp, f_MethaneDensityFrom_Volume_Temp;
std::function<double(double, double, double)> f_MethaneAirConcFrom_water_Temp;

std::function<double(double)> f_NitrogenOxideProduction_Temp;
std::function<double(double)> f_NO_Production_Moist;
std::function<double(double)> f_N2O_Production_Moist;
std::function<double(double)> f_NO_Production_PH;
std::function<double(double)> f_NO_Production;
std::function<double(double)> f_N2O_Production;
std::function<double(double)> f_AnaerobicExchangeEfficiency;
std::function<double(double)> f_DenitrifierAnaerobicFracResponse;



double  CH4_InitStorage;
;
bool YearShift, FullYear;

/*
double N2O_TempFunctionL(size_t Layer);
double N2O_TempFunction(double Value);
double N2O_MoistureFunctionL(size_t Layer);
double N2O_MoistureFunction(double Value);
double NO_MoistureFunctionL(size_t Layer);
double NO_MoistureFunction(double Value);

double NO_pHFunctionL(size_t Layer);
double NO_pHFunction(double Value);
double ExCoefFunctionL(size_t Layer);
double ExCoefFunction(double AnVolFraction, double AirPorosity);*/
bool DenitrifierUpdate();


};

