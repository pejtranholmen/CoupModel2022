#include "./Irrigation_Functions.h"
Irrigation_Functions::Irrigation_Functions(void)
{
}
Irrigation_Functions::~Irrigation_Functions(void)
{
}



bool Irrigation_Functions::Def()
{

	Surface_Water::Def();
	ModuleNo=8;
//    ! Snow surface energy balance
	Sw* pSw;
	pSw= new Sw(&Dripper, datatype::SINGLE, elements::WATER, fysprocess::INFILTRATION, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pSw,    "Dripper",0,"Off|On","WaterEq > 0|Irrigation > 0",114) ; 
	pSw= new Sw(&UnitIrrig, datatype::SINGLE, elements::WATER, fysprocess::INFILTRATION, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pSw,  "UnitIrrig",0,"Rate|Amount","WaterEq > 0|IrrigationInput =0|Irrigation > 0")  ;
	pSw= new Sw(&IrrigationInput, datatype::SINGLE, elements::WATER, fysprocess::INFILTRATION, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pSw ,"IrrigationInput",0,"Driving variable|Automatic Generation|Auto but only with plant","WaterEq > 0|Irrigation > 0",200);

	Xs *pXs;
	pXs= new Xs(&DripContainer, datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::STORAGE, bioprocess::NOBPROC, userlevel::NORMAL);

	Define(pXs,  "DripContainer"	, 0.	,UNIT_TYPES::WATERMASS_UNIT		, "Dripper = 1");
	Ts *pTs;
	pTs= new Ts(&DripFill, datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pTs,   "DripFill"		, 0.	,UNIT_TYPES::WATERFLOW_UNIT	, "Dripper = 1");
	pTs= new Ts(&DripOutlet, datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pTs,  "DripOutlet"		, 0.	,UNIT_TYPES::WATERFLOW_UNIT	, "Dripper = 1");

	Ps *pPs;
	pPs= new Ps(&IStoreLayer, datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pPs,"IStoreLayer",4.,"#","IrrigationInput > 0",1.,100.,1.,10.);
	pPs= new Ps(&IStoreMin, datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pPs, "IStoreMin"  ,50.,UNIT_TYPES::WATERMASS_UNIT,"IrrigationInput > 0",0., 400.,0.,100.);
	pPs= new Ps(&IrrigRate  , datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pPs,  "IrrigRate"  ,50.,UNIT_TYPES::WATERFLOW_UNIT,"IrrigationInput >0",0., 2000.,0., 500.);
	pPs= new Ps(&IrrigAmount, datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pPs,  "IrrigAmount",20.,UNIT_TYPES::WATERMASS_UNIT,"IrrigationInput > 0",0., 400., 0., 100.);
	
	pPs= new Ps(&IrrigV_Index, datatype::SINGLE, elements::WATER, fysprocess::NOFPROC, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pPs,"Index in File",1.,"#","IrrigationInput =0|Irrigation > 0",1.,100.);
	pPs= new Ps(&SoilIrrigF, datatype::SINGLE, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
 	Define(pPs,"SoilIrrigF", 0.,UNIT_TYPES::NO_UNIT,"Irrigation > 0",0.,1.);
	pPs= new Ps(&DripIrrigCover, datatype::SINGLE, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pPs,  "DripIrrigCover", 0.2,UNIT_TYPES::NO_UNIT,"Irrigation >0|Dripper>0",0.,1.);
	pPs= new Ps(&DripIrrigXCenter, datatype::SINGLE, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pPs, "DripIrrigXCentre", 0.5,UNIT_TYPES::NO_UNIT,"Irrigation >0|Dripper>0",0.,1.);
	pPs= new Ps(&DripIrrigRate, datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pPs,  "DripIrrigRate", 100.,UNIT_TYPES::WATERFLOW_UNIT,"Irrigation >0|Dripper>0",0.,10000.);


	P *pP;
	NE *pNL;
	pNL=m_pModelMap->GetNEPointer("Number of Layers");
	vector <double> initv;
	initv.assign(p_Soil_WaterF->NL,0);
	initv[0]=1.;

	pP=m_pModelMap->GetPPointer("mUpper Depth");
	mTab_Dripper.push_back(pP);
	pP=m_pModelMap->GetPPointer("mLower Depth");
	mTab_Dripper.push_back(pP);
	pP= new P(&DrippInfilDistF,pNL, datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);

	Define(pP, pNL, "InfilDistF"	,initv, UNIT_TYPES::NO_UNIT,"Dripper>0",0.,1.);

	mTab_Dripper.push_back(pP);
	Tab *pTab;
	pTab= new Tab(&mTab_Dripper, datatype::IRRIGATIONCONTAINER, elements::WATER, fysprocess::TECH_REGULATOR, bioprocess::NOBPROC, userlevel::NORMAL);
	Define(pTab,"Depth Distribution of Irrigation",3);


return true;
}



